#include <iostream>

extern int x;

int main() {
    
    std::cout << "Hello world" << std::endl;
    
    std::cout << x;
    
    return 0;
}

