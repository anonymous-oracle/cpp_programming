// Section 19
// Challenge 4
// Copy Romeo and Juliet with line numbers
#include <iostream>

int main() {
    
    return 0;
}

